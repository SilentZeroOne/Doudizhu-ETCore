﻿namespace ETModel
{
	public enum MotionType
	{
		None,
		Idle,
		Run,
	}
}