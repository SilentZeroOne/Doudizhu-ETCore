﻿namespace ETModel
{
	public enum LogType
	{
		Warning,
		Info,
		Debug,
		Error,
	}
}
