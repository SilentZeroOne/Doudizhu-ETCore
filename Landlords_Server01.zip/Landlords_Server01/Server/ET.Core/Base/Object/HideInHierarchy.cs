using System;

namespace ETModel
{
    public class HideInHierarchy: Attribute
    {
    }
}