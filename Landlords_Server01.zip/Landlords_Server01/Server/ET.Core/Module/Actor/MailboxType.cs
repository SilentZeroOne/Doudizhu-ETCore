﻿namespace ETModel
{
    public static partial class MailboxType
    {
	    public const string MessageDispatcher = "Dispatcher";
		public const string GateSession = "GateSession";
    }
}
