﻿namespace ETModel
{
	public interface INumericWatcher
	{
		void Run(long id, int value);
	}
}
