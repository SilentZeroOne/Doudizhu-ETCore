﻿namespace ETModel
{
	public interface IActorLocationMessage : IActorRequest
	{
	}

	public interface IActorLocationRequest : IActorRequest
	{
	}
	
	public interface IActorLocationResponse : IActorResponse
	{
	}
}