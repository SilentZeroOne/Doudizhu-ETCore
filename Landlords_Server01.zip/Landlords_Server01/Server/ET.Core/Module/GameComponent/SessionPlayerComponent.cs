﻿namespace ETModel
{
	public class SessionPlayerComponent : Component
	{
		public Player Player;
	}
}