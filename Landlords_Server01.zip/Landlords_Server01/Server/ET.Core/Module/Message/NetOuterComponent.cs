﻿namespace ETModel
{
	public class NetOuterComponent : NetworkComponent
	{
		public NetworkProtocol Protocol = NetworkProtocol.TCP;
	}
}