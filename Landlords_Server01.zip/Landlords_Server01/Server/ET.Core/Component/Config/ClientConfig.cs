﻿namespace ETModel
{
	public class ClientConfig: AConfigComponent
	{
		public string Address { get; set; }
	}
}