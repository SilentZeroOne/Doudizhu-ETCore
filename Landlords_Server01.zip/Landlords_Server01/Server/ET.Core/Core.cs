﻿using System.Collections;
using System.Collections.Generic;

namespace ETModel
{
    public class Core 
    {
        void Start(){}
    }
}